using System;
using UnityEngine;
using UnityEngine.EventSystems;

public class BuildTower : MonoBehaviour
{
    [SerializeField] GameObject MenuPopup;
    [SerializeField] GameObject[] ListTower;
    GameObject InstantObj;
    Collider _pedestalCollider;
    [SerializeField] Camera cam;
    public void ActiveMenu(bool show = true)
    {
        MenuPopup.SetActive(show);

    }
    public void Canon()
    {
        ActiveMenu(false);
        if (ListTower[0] != null)
        {
            Create_Instant(ListTower[0]);
           
        }
        
    }
    public void Catapult()
    {
        ActiveMenu(false);
        if (ListTower[1] != null)
        {
            Create_Instant(ListTower[1]);

        }

    }
    void Create_Instant(GameObject Obj)
    {
       
        ActiveMenu(false);

        if (_pedestalCollider)
        {
            InstantObj = Instantiate(Obj, _pedestalCollider.gameObject.transform.position, Quaternion.identity);

            Bounds bounds = _pedestalCollider.bounds;

            var pedestalTop_Y = bounds.max.y;

            var turretHeight = InstantObj.GetComponent<BoxCollider>().bounds.size.y;

            if (InstantObj != null)
            {
                InstantObj.transform.position = new Vector3(_pedestalCollider.transform.position.x, pedestalTop_Y, _pedestalCollider.transform.position.z);

                InstantObj.GetComponent<BoxCollider>().enabled = true;

                InstantObj.GetComponent<SphereCollider>().enabled = true;

                _pedestalCollider.tag = "Occupied";

                InstantObj.GetComponent<CanonControl>().Pedestal = _pedestalCollider.gameObject;
                InstantObj.GetComponent<CanonControl>().NameID = string.Format(" Tower_{0}", DateTime.Now.Ticks);
            }

        }

        InstantObj = null;

    }
   

    TouchPhase Tap
    {
        get
        {

            if (Input.touchCount > 0)
            {
                switch (Input.GetTouch(0).phase)
                {
                    case TouchPhase.Began:
                        {
                            //Begin tap
                            return TouchPhase.Began;
                        }
                    case TouchPhase.Moved:
                        {
                            //Move finger
                            return TouchPhase.Moved;
                        }
                    case TouchPhase.Stationary:
                        {
                            //Touch long time
                            return TouchPhase.Stationary;
                        }
                    case TouchPhase.Ended:
                        {
                            //End tap
                            return TouchPhase.Ended;
                        }

                    default:
                        //Cancel tap
                        return TouchPhase.Canceled;
                }
            }
            else return TouchPhase.Canceled;
        }
    }
    Vector2 Position_Of_Tap => Input.GetTouch(0).position;

    RaycastHit GetHit_ExceptLayer(string LayerName = "")
    {

        Ray ray = Camera.main.ScreenPointToRay(Position_Of_Tap);
        RaycastHit hit;

        switch (string.IsNullOrEmpty(LayerName))
        {
            case true:
                return Physics.Raycast(ray, out hit) ? hit : default;

            default:
                {
                    int layer = LayerMask.NameToLayer(LayerName);

                    if (layer < 0) // Layer is not exist
                    {
                        Debug.LogError($"Layer ({LayerName}) is not exited,(Raycasthit in BuildTower class not true)");
                        return default;
                    }
                    return Physics.Raycast(ray, out hit, Mathf.Infinity, ~(1 << layer)) ? hit : default;
                }
        }

    }
    void Show_MenuBuild()
    {
        //click Gameobject and is not UI
        if (!EventSystem.current.IsPointerOverGameObject())
        {
            var hit = GetHit_ExceptLayer("Turret");

            var collider = hit.collider;

            if (collider && collider.gameObject.CompareTag("Platform"))
            {
                _pedestalCollider = collider;

                ActiveMenu();

                //Show popup at Position of tap
                MenuPopup.transform.position = Position_Of_Tap;

                //order the last row to show on top
                MenuPopup.transform.SetAsLastSibling();
            }
        }
        else
        {
            ShowMessage("Click on UI");
        }
    }
  
   
    void ShowMessage(string message)
    {
        Debug.Log(message);

    }
    bool tap = false;
    bool keep = false;
    bool move = false;
    bool end = false;

    void Update()
    {

        if (SystemTouch.SingelTap)
        {
            Debug.Log("tap");
        }
        if (SystemTouch.MoveTap)
        {
            Debug.Log("move");
        }
        //switch (Input.touchCount)
        //{
        //    case 1:
        //        {
        //            switch (Tap)
        //            {
        //                case TouchPhase.Began:                            
        //                    tap = true;
                           
        //                    break;
        //                case TouchPhase.Moved:                                                      
        //                    move = true;                           
                           
        //                    break;
        //                case TouchPhase.Stationary:
                            
        //                    keep = true;                                                        
        //                    break;
        //                case TouchPhase.Ended:
        //                    end = true;
        //                    if(tap && keep && end && !move)
        //                    {
        //                        Debug.Log("tap");
        //                        Show_MenuBuild();
        //                        tap = false;
        //                        keep = false;
        //                        end = false;
        //                    }
        //                    if(tap && keep && move && end)
        //                    {
        //                        Debug.Log("pan");
        //                        PanCamera(Input.GetTouch(0).position);
        //                        tap = false;
        //                        keep = false;
        //                        move = false;
        //                        end = false;
        //                    }
        //                    break;

        //                default:

        //                    break;
        //            }
                   
                    

        //            break;
        //        }
        //    default: //Use two finger
        //        break;
        //}


        

    }
    public float zoomSpeed = 0.1f;         // zoom
    public float moveSpeed = 0.01f;        // slide
    public float minZoom = 5f;             // min zoom 
    public float maxZoom = 20f;            // max zoom

    
    public Vector2 minBounds;   
    public Vector2 maxBounds;   

    private Vector2 lastPanPosition;
    private int panFingerId;
    private bool isPanning;
    
    void PanCamera(Vector2 newPanPosition)
    {
        Vector2 offset = cam.ScreenToViewportPoint(lastPanPosition - newPanPosition);
        Vector3 move = new Vector3(offset.x * moveSpeed, 0, offset.y * moveSpeed);

        
        Camera.main.transform.Translate(move, Space.World);

        // limit bound
        Vector3 pos = Camera.main.transform.position;
        pos.x = Mathf.Clamp(pos.x, minBounds.x, maxBounds.x);
        pos.z = Mathf.Clamp(pos.z, minBounds.y, maxBounds.y);
        Camera.main.transform.position = pos;

        lastPanPosition = newPanPosition;
    }

    void ZoomCamera(float delta)
    {
        if (cam.orthographic)
        {
            cam.orthographicSize -= delta;
            cam.orthographicSize = Mathf.Clamp(cam.orthographicSize, minZoom, maxZoom);
        }
        else
        {
            cam.fieldOfView -= delta;
            cam.fieldOfView = Mathf.Clamp(cam.fieldOfView, minZoom, maxZoom);
        }
    }
}
