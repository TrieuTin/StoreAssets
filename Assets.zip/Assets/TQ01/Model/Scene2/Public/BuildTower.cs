using System;
using UnityEngine;
using UnityEngine.EventSystems;

public class BuildTower : MonoBehaviour
{
    [SerializeField] GameObject MenuPopup;
    [SerializeField] GameObject[] ListTower;
    GameObject InstantObj;
    Collider _pedestalCollider;
    
    public void ActiveMenu(bool show = true)
    {
        MenuPopup.SetActive(show);

    }
    public void Canon()
    {
        ActiveMenu(false);
        if (ListTower[0] != null)
        {
            Create_Instant(ListTower[0]);
           
        }
        
    }
    public void Catapult()
    {
        ActiveMenu(false);
        if (ListTower[1] != null)
        {
            Create_Instant(ListTower[1]);

        }

    }
    void Create_Instant(GameObject Obj)
    {
       
        ActiveMenu(false);

        if (_pedestalCollider)
        {
            InstantObj = Instantiate(Obj, _pedestalCollider.gameObject.transform.position, Quaternion.identity);

            Bounds bounds = _pedestalCollider.bounds;

            var pedestalTop_Y = bounds.max.y;

            var turretHeight = InstantObj.GetComponent<BoxCollider>().bounds.size.y;

            if (InstantObj != null)
            {
                InstantObj.transform.position = new Vector3(_pedestalCollider.transform.position.x, pedestalTop_Y, _pedestalCollider.transform.position.z);

                InstantObj.GetComponent<BoxCollider>().enabled = true;

                InstantObj.GetComponent<SphereCollider>().enabled = true;

                _pedestalCollider.tag = "Occupied";

                InstantObj.GetComponent<CanonControl>().Pedestal = _pedestalCollider.gameObject;
                InstantObj.GetComponent<CanonControl>().NameID = string.Format(" Tower_{0}", DateTime.Now.Ticks);
            }

        }

        InstantObj = null;

    }
   

  
    Vector2 Position_Of_Tap => Input.GetTouch(0).position;

    RaycastHit GetHit_ExceptLayer(string LayerName = "")
    {

        Ray ray = Camera.main.ScreenPointToRay(Position_Of_Tap);
        RaycastHit hit;

        switch (string.IsNullOrEmpty(LayerName))
        {
            case true:
                return Physics.Raycast(ray, out hit) ? hit : default;

            default:
                {
                    int layer = LayerMask.NameToLayer(LayerName);

                    if (layer < 0) // Layer is not exist
                    {
                        Debug.LogError($"Layer ({LayerName}) is not exited,(Raycasthit in BuildTower class not true)");
                        return default;
                    }
                    return Physics.Raycast(ray, out hit, Mathf.Infinity, ~(1 << layer)) ? hit : default;
                }
        }

    }
    void Show_MenuBuild()
    {
        //click Gameobject and is not UI
        if (!EventSystem.current.IsPointerOverGameObject())
        {
            var hit = GetHit_ExceptLayer("Turret");

            var collider = hit.collider;

            if (collider && collider.gameObject.CompareTag("Platform"))
            {
                _pedestalCollider = collider;

                ActiveMenu();

                //Show popup at Position of tap
                MenuPopup.transform.position = Position_Of_Tap;

                //order the last row to show on top
                MenuPopup.transform.SetAsLastSibling();
            }
        }
        else
        {
            ShowMessage("Click on UI");
        }
    }
  
   
    void ShowMessage(string message)
    {
        Debug.Log(message);

    }
    private float touchTimer = 0f;
    public float stationaryTimeThreshold = 0.5f;
 
    void Update()
    {

        //if one finger touched
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);

            //start touch
            if (touch.phase == TouchPhase.Began)
            {
                //set timer = 0
                touchTimer = 0f;
            }

            // if finger moved
            else if (touch.phase == TouchPhase.Moved)
            {
                
                touchTimer = 0f;

                //move CAM
                
            }

            // Stationary
            else if (touch.phase == TouchPhase.Stationary)
            {
               //increase timer
                touchTimer += Time.deltaTime;

                //increase to stationary time threshold
                if (touchTimer >= stationaryTimeThreshold)
                {
                    //set timer
                    touchTimer = 0f;
                    //show menu
                    Show_MenuBuild();
                }
            }

            //end
            else if (touch.phase == TouchPhase.Ended)
            {
                
                touchTimer = 0f;
            }
        }
    }     
}
