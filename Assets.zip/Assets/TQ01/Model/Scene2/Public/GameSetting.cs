using UnityEngine;
using System.Collections.Generic;

public class GameSetting : MonoBehaviour
{
    public int SpawnCanonQty = 10;
    
    public int Wave = 1;
    public List<GameObject> ListObjects=new List<GameObject>();
}
