using UnityEngine;

public class GameSetting : MonoBehaviour
{
    public int SpawnCanonQty = 1;
}
