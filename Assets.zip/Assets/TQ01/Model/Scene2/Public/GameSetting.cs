using UnityEngine;

public class GameSetting : MonoBehaviour
{
    public int SpawnCanonQty = 10;
    public static int WaveTotal = 10;
    public int Wave = 0;
}
