using System.Collections;
using UnityEngine;

public class Spawn_Enemy : MonoBehaviour
{
    public GameObject[] Prefab;
    public Transform Target;
    int _enemy_Stack = 0;
    [SerializeField] int BarrackID;
    int _barrack;
    GameSetting gs;
    public bool isplaying = false;
    float Start_Time = 1f;
    float Rate_Time = 6f;
    float downtime = 0;
    
    void Start()
    {
       gs = GameObject.Find("GamePlay").GetComponent<GameSetting>();
        //InvokeRepeating("Spawn", Start_Time, Rate_Time);

       // Setting();
        StartCoroutine(SpawnLoop());
    }

    void Setting()
    {
        //var w = GameObject.Find("GamePlay").GetComponent<GameSetting>();
        if(gs.Wave <10 )
        {
            if (gs.ListObjects.Count == 0)
            {                
                Debug.Log("Wave:" + gs.Wave);

                gs.SpawnCanonQty = 4; ;


                if (gs.Wave % 2 == 0)
                {
                    _barrack = 2;
                    BarrackID = 2;
                    _enemy_Stack = 1;
                }
                else
                {

                    _barrack = 1;
                    BarrackID= 1;
                    _enemy_Stack = 0;
                }


                Debug.Log("Barrack ID:" + BarrackID +"; " +_barrack) ;
                Debug.Log("List :" + gs.ListObjects.Count);

                if (_barrack == BarrackID )
                {
                    Debug.Log("PLAY");

                    isplaying = true;
                }
            }
            
        }
    }
    IEnumerator SpawnLoop()
    {
        while (true)
        {
            if(isplaying)
                Spawn();
            
            yield return new WaitForSeconds(Rate_Time);
        }
    }
  

    private void Spawn()
    {
        // downtime -= Time.deltaTime;

        

        if (gs.SpawnCanonQty > 0)
        {

            var instant = Instantiate(Prefab[_enemy_Stack], this.transform.position, Quaternion.identity);

            instant.GetComponent<CanonAgent>().Destination = Target;

            instant.GetComponent<CanonAgent>().Speed = _enemy_Stack == 0 ? 1f : .6f;

            gs.SpawnCanonQty--;

            if (gs.ListObjects != null) gs.ListObjects.Add(instant);


        }
        else
        {
            Debug.Log(string.Format("Stop Coroutine")); 
            
            if (gs.ListObjects.Count == 0)
            { 

                gs.Wave++; 
                isplaying = false;
                Setting();
            }
        } 
        
    }
    private void Update()
    {
       
    }
}
