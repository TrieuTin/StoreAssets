using UnityEngine;

public class Spawn_Enemy : MonoBehaviour
{
    public GameObject[] Prefab;
    public Transform Target;
    [SerializeField] int enemy_Stack = 0;

    public float Start_Time = 1f;
    public float Rate_Time = 7f;
    void Start()
    {
        InvokeRepeating("Spawn", Start_Time, Rate_Time);
    }

    private void Spawn()
    {

        if (GameObject.Find("GamePlay").GetComponent<GameSetting>().SpawnCanonQty > 0)
        {

            var instant = Instantiate(Prefab[enemy_Stack], this.transform.position, Quaternion.identity);

            instant.GetComponent<CanonAgent>().Destination = Target;
            instant.GetComponent<CanonAgent>().Speed = enemy_Stack == 0 ? 1f : .3f;
            GameObject.Find("GamePlay").GetComponent<GameSetting>().SpawnCanonQty--;
        }

    }
}
