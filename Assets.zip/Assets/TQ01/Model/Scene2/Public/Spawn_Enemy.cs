using UnityEngine;

public class Spawn_Enemy : MonoBehaviour
{
    public GameObject[] Prefab;
    public Transform Target;
    int _enemy_Stack = 0;
    [SerializeField] int BarrackID;
    int _barrack;
    GameSetting gs;
    bool isplaying = false;
    public float Start_Time = 1f;
    public float Rate_Time = 7f;
    float downtime = 0;
    void Start()
    {
        gs = GameObject.Find("GamePlay").GetComponent<GameSetting>();
        //InvokeRepeating("Spawn", Start_Time, Rate_Time);
    }

    void Setting()
    {
        var w = gs.Wave;
        var qty = gs.SpawnCanonQty;
        if(w <10 && !isplaying)
        {
            if (qty <= 0) { gs.SpawnCanonQty = 10; w++; }

            if(w % 2 == 0)
            {
                _barrack = 1;
                _enemy_Stack = 1;
            }
            else
            {
                _barrack = 2;
                _enemy_Stack = 0;
            }
            downtime -= Time.deltaTime;
            if (downtime <= 0)
            {
                if (_barrack == BarrackID)
                {

                    InvokeRepeating(nameof(Spawn), Start_Time, Rate_Time);
                }
                downtime = Rate_Time;
            }
        }


    }

    private void Spawn()
    {

        if (GameObject.Find("GamePlay").GetComponent<GameSetting>().SpawnCanonQty > 0)
        {

            var instant = Instantiate(Prefab[_enemy_Stack], this.transform.position, Quaternion.identity);

            instant.GetComponent<CanonAgent>().Destination = Target;
            instant.GetComponent<CanonAgent>().Speed = _enemy_Stack == 0 ? 1f : .6f;
            GameObject.Find("GamePlay").GetComponent<GameSetting>().SpawnCanonQty--;
        }else
        {
            CancelInvoke(nameof(Spawn));
            isplaying = false;
        }

    }
    private void Update()
    {
        Setting();

     
    }
}
