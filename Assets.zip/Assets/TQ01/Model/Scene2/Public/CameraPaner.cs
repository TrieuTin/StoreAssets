using UnityEngine;

public class CameraPaner : MonoBehaviour
{
    float panspeed = 6f;
    Camera _cam;
    private void Awake()
    {
        _cam = GetComponentInChildren<Camera>();
    }
    private void Update()
    {
        var panPosition = Input.GetTouch(0).position;
        transform.position += Quaternion.Euler(0, _cam.transform.eulerAngles.y, 0) * new Vector3(panPosition.x, 0, panPosition.y) * (panspeed * Time.deltaTime);
    }

}
