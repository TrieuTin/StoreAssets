using UnityEngine;

public class CameraPaner : MonoBehaviour
{
    float panspeed = 2.5f;
    public Vector2 panLimit;
   // public Transform mapBoundary;

    public float zoomSpeed = 1.5f;
    public float minZoom = 50f;
    public float maxZoom = 150f;
    void Start()
    {      
        //if (mapBoundary != null)
        //{
     
        //    BoxCollider mapCollider = mapBoundary.GetComponent<BoxCollider>();
        //    if (mapCollider != null)
        //    {
        //        panLimit.x = mapCollider.bounds.extents.x;
        //        panLimit.y = mapCollider.bounds.extents.z;
        //    }
        //}
    }
    private void Update()
    {
        switch (Input.touchCount)
        {
            case 1:
                PanCam();
                break;
            case 2:
                ZoomCam();
                break;
            default:
                break;
        }
        //PanCam();
       
    }
    void ZoomCam()
    {

        //get touch of two fingers
        Touch touchZero = Input.GetTouch(0);
        Touch touchOne = Input.GetTouch(1);

        //get postion of two fingers at previous frame
        Vector2 touchZeroPrevPos = touchZero.position - touchZero.deltaPosition;
        Vector2 touchOnePrevPos = touchOne.position - touchOne.deltaPosition;

        // Calculation distant beweent finger1 and finger2 at current frame and previous frame 
        float prevDistance = Vector2.Distance(touchZeroPrevPos, touchOnePrevPos);
        float currentDistance = Vector2.Distance(touchZero.position, touchOne.position);

        // Calculating change distance to zoom  
        float deltaDistance = prevDistance - currentDistance;

        // get zoom camera

        Camera.main.orthographicSize += deltaDistance * zoomSpeed * Time.deltaTime ;
      
        // limit zoom
       Camera.main.orthographicSize = Mathf.Clamp(Camera.main.orthographicSize, 5, 15);
    }
    void PanCam()
    {
        if (SystemTouch.Tap == TouchPhase.Moved)
        {
            Debug.Log("MOVE");
            Vector2 touchDeltaPosition = Input.GetTouch(0).deltaPosition;
            //di chuyen theo voi ngon tay
            Vector3 pan = new Vector3(touchDeltaPosition.x * panspeed * Time.deltaTime, -touchDeltaPosition.y * panspeed * Time.deltaTime, 0);
            transform.Translate(pan, Space.World);

            // limit camera
            Vector3 clampedPosition = transform.position;
            clampedPosition.x = Mathf.Clamp(clampedPosition.x, -panLimit.x, panLimit.x);
            clampedPosition.y = Mathf.Clamp(clampedPosition.y, -panLimit.y, panLimit.y);
            transform.position = clampedPosition;
        }

    }
}
