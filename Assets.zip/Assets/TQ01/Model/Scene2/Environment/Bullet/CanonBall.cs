using System;
using UnityEngine;

public class CanonBall : MonoBehaviour
{
    public float speed = 2f;       
    public float lifeTime = 2.50f;    
    public int damage = 50;
    public string parentTag = "";
    Rigidbody rb;
    private void Awake()
    {
        rb = GetComponent<Rigidbody>();
        rb.isKinematic = false;
    }
  
    private void OnEnable()
    {
        if (rb != null)
        {
            rb.linearVelocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
        }
        Invoke(nameof(DestroySelf), lifeTime);
    }

    private void DestroySelf()
    {
        CancelInvoke(nameof(DestroySelf));
        Destroy(gameObject);
    }
   
   
    private void OnTriggerEnter(Collider other)
    {
        if (other is BoxCollider bc)
        {            
            if (!other.CompareTag(parentTag))
            {
                var damageable = other.GetComponent<IDamageable>();
                if (damageable != null)
                {
                    damageable.TakeDamage(damage);
                }
                DestroySelf();
            }
        }
    }

  
    public void Launch(Vector3 direction)
    {
        if (rb == null) rb = GetComponent<Rigidbody>();

        rb.AddForce(direction.normalized * speed, ForceMode.VelocityChange);
    }


}
