using UnityEngine;

public class CanonControl : MonoBehaviour, IDamageable
{
    Quaternion StartgunRotation;
    Quaternion StartbodyRotation;

    [SerializeField]GameObject body;
    [SerializeField]GameObject gun;

    GameObject Enemy;

    private string _nameid;
    private GameObject _pedestal;

    [Header("----------Fire----------")]
    [SerializeField] GameObject cannonballPrefab;
    [SerializeField] Transform holeOfGun;
    private float fireForce = 5;
    private float fireCooldown = 2f;   
    private float cooldownTimer = 0f;



    [Header("-------Blood------")]
    [SerializeField] UnityEngine.UI.Slider Blood_Prefab;
    private UnityEngine.UI.Slider _blood;
    private const float max_blood = 100;
    private float current_blood;

    GameSound gamesound;

    public GameObject Pedestal { get => _pedestal; set => _pedestal = value; }
    public string NameID { get => _nameid; set => _nameid = value; }

    private void Awake()
    {
        gamesound = GameObject.FindGameObjectWithTag("Audio").GetComponent<GameSound>();
    }
    void Start()
    {
       // StartbodyRotation = body.transform.rotation;
       // StartgunRotation = gun.transform.rotation;
        if (Blood_Prefab)
        {

            _blood = Instantiate(Blood_Prefab, this.transform.position, Quaternion.identity);
            _blood.transform.SetParent(GameObject.Find("Canvas").transform);

            current_blood = max_blood;

            _blood.maxValue = max_blood;
            _blood.value = current_blood;

        }
        else MessageShow("Blood prefab is null");
    }
    void MessageShow(string text)
    {
        Debug.Log(text);
    }
    void OnTriggerEnter(Collider other)
    {
        if (Enemy == null && other.gameObject.CompareTag("enemy"))
        {
            Enemy = other.gameObject;
            Enemy.GetComponent<CanonAgent>().Enemy = Enemy;
        }   
            
            
    }
   

    void OnTriggerExit(Collider other)
    {

        if (other.gameObject.CompareTag("enemy") && Enemy != null && other.gameObject == Enemy)
        {
            //Enemy.GetComponent<FindDestination>().CLearTurret();

            var enemy = Enemy.GetComponent<CanonAgent>();

            enemy.Enemy = null;

            

            Enemy = null;
           // Test_Explosion();
        }
    }
    public void Fire()
    {
        if (cannonballPrefab == null || holeOfGun == null) return;

        
        GameObject bullet = Instantiate(cannonballPrefab, holeOfGun.position, holeOfGun.rotation);

        var cb = bullet.GetComponent<CanonBall>();
        if (cb != null)
        {
            cb.speed = fireForce;
            cb.damage = 80;
            cb.parentTag = gameObject.tag;
            cb.Launch(holeOfGun.forward); // direction
                                          // gamesound.PlaySFX(gamesound.shot,.5f);
            Audio.Shot(.6f);
        }
    }
    void Update()
    {
        if (_blood) //show bloodbar on head
        {
            Renderer rend = GetComponentInChildren<Renderer>();
            float height = rend.bounds.size.y;
            Vector3 top = rend.bounds.center + Vector3.up * (height / 2);
            Vector3 screenPos = Camera.main.WorldToScreenPoint(top + Vector3.up * .8f);
            _blood.GetComponent<RectTransform>().position = screenPos;
        }


        Attack();

        if (_blood.value <= 0) Die();
    }

    public void TakeDamage(int amount)
    {
        if (_blood.value > 0)
        {
            if (amount > 0) current_blood -= amount;

            _blood.value = current_blood;
        }
      
    }

    public void Die()
    {
        Effect.DisplayExplosion(this.transform.position,4f,1.5f);
        Destroy(gameObject, .1f);
        Destroy(_blood.gameObject, .1f);
        _pedestal.tag = "Platform";
    }

    public void Attack()
    {

        if (Enemy != null)
        {
            cooldownTimer -= Time.deltaTime;

            gun.transform.rotation = LookGameObject.Rotate_CoordinateAxis_X(Enemy, body);

            body.transform.rotation = LookGameObject.Rorate_CoordinateAxis_Y(Enemy, gun, 2.8f);

            var angleshot = Vector3.Angle(gun.transform.position, Enemy.transform.position);


            if (angleshot <= 10f)
            {
                if (cooldownTimer <= 0f)
                {
                    Fire();
                    cooldownTimer = fireCooldown; // wait 2s 
                }
            }

        }
    }
}
