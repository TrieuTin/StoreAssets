using UnityEngine;
using UnityEngine.AI;
using UnityEngine.UI;

public class CanonAgent : MonoBehaviour,IDamageable
{
    bool isFired = false;

    public float Speed=1f;
    public Transform Destination;
    NavMeshAgent _agent;                        
    Quaternion StartgunRotation;

    [SerializeField] Slider Health_Prefab;
    private Slider _health;
    
    [SerializeField] Transform firePosition;
    [SerializeField] GameObject bullet_prefab;

    [SerializeField] const int max_Blood=100;
    private int currentBlood = 0;
    private GameObject _enemy;
    private float cooldownTimer = 0f;


    [SerializeField] GameObject body;


    string ObjectName { get => gameObject.name.Split('(')[0].Trim(); }
    
    public GameObject Enemy { get => _enemy; set => _enemy = value; }

    void Start()
    {
        //Audio = GetComponent<AudioSource>();
       
        _health = Instantiate(Health_Prefab, this.transform.position, Quaternion.identity);
        _health.transform.SetParent(GameObject.Find("Canvas").transform);

        if (_health)
        {
            currentBlood = max_Blood;
            _health.maxValue = max_Blood;
            _health.value = currentBlood;

        }

        if (Destination != null)
        {
           
            _agent = GetComponent<NavMeshAgent>();
            _agent.SetDestination(Destination.position);
            _agent.speed = Speed;
            
            //StartgunRotation = gun.transform.rotation;
        }

    }

  
   
    void Update()
    {
        if (_agent !=null)
        {

            if (_agent.remainingDistance <= .1f)
            {
                Completed_duty();
            }
            if (_health) //show bloodbar on head
            {
                Renderer rend = GetComponentInChildren<Renderer>();

                float height = rend.bounds.size.y;

                Vector3 top = rend.bounds.center + Vector3.up * (height / 2);

                Vector3 screenPos = Camera.main.WorldToScreenPoint(top + Vector3.up * .5f);

                _health.GetComponent<RectTransform>().position = screenPos;
            }
            CheckAgent();
            Attack();
            if (_health.value <= 0) Die();
        }
        else
        {

            Debug.Log("Mat _agent");

            _agent = GetComponent<NavMeshAgent>();
            _agent.SetDestination(Destination.position);
        }


    }

    public void TakeDamage(int amount)
    {
        if(_health.value > 0)
        {
            if (amount > 0) currentBlood -= amount;

            _health.value = currentBlood;

           
        }
       
    }
    private void Completed_duty()
    {
        if (_agent!=null)
            _agent.ResetPath();
  
        var gs = GameObject.Find("GamePlay").GetComponent<GameSetting>().ListObjects;
        
        if (gs.Count > 0) gs.Remove(gameObject);

     
        Destroy(this.gameObject, 0.1f);
        Destroy(this._health.gameObject, 0.1f);
      
        _agent = null;

    }
    public void Die()
    {
        Effect.DisplayExplosion(this.transform.position, 2.5f, 0.4f);
        Completed_duty();
       
    }
    void CheckAgent()
    {
        if (_agent == null)
        {
          //  Debug.Log("Agent is null");
            //_agent.ResetPath();
            _agent = GetComponent<NavMeshAgent>();
            _agent.SetDestination(Destination.position);
        }

        if (_agent.isPathStale)
        {//Lost destination
            
            Debug.Log("Agent path is stale/invalid! Re-setting destination.");
            //_agent.ResetPath();
            //_agent.SetDestination(Destination.position);
        }

        
        if (_agent.pathStatus == NavMeshPathStatus.PathPartial)
        {
            //destination out of Path
            Debug.Log("Path is only partial. Target might be unreachable.");
        }
        
        if (_agent.pathStatus == NavMeshPathStatus.PathInvalid)
        {
            //not found destination
            Debug.Log("Path is invalid! Cannot reach target.");
        }
    }
  
    public void Attack()
    {
        if (ObjectName == "CanonEnemy")
        {

            FireTime();
        }
        else
        {
            //Catapult fire

            FireTime(4);
        }


    }
    void FireTime(float restTime = 2)
    {
        cooldownTimer -= Time.deltaTime;
        if (cooldownTimer <= 0)
        {
            if (ObjectName == "CanonEnemy")

            {
                Fire();
            }
            else
            {
               // action.SetBool("anm_fire", true);
                Fire2();
            }
            cooldownTimer = restTime;
        }
        else
        {
            //action.SetBool("anm_fire", false);
        }
    }
    void Fire()
    {

        GameObject bullet = Instantiate(bullet_prefab, firePosition.position, firePosition.rotation);

        var cb = bullet.GetComponent<CanonBall>();

        if (cb != null)
        {            
            switch (currentBlood)
            {
                case int n when n >= 70:
                    {

                        //cb.speed = 15f;
                        cb.damage = 15;
                        break;
                    }
                case int n when n >= 50:
                    {
                        //cb.speed = 10f;
                        cb.damage = 10;
                        break;
                    }

                default:
                   // cb.speed = 7f;
                    cb.damage = 5;
                    break;
            }




            cb.parentTag = gameObject.tag;
            cb.Launch(firePosition.forward); // direction
                                             // gamesound.PlaySFX(gamesound.shot,.5f);
            Audio.Shot(.6f);                        
        }
    }
    void Fire2()
    {
        GameObject bullet = Instantiate(bullet_prefab, firePosition.position, firePosition.rotation);
        var cb = bullet.GetComponent<CanonBall>();

        if (cb != null)
        {

            switch (currentBlood)
            {
                case int n when n >= 70:
                    {

                        //cb.speed = 15f;
                        cb.damage = 50;
                        break;
                    }
                case int n when n >= 50:
                    {
                        // cb.speed = 10f;
                        cb.damage = 30;
                        break;
                    }

                default:
                    //  cb.speed = 7f;
                    cb.damage = 25;
                    break;
            }




            cb.parentTag = gameObject.tag;

            cb.ThrowOut(firePosition); // direction
                                       // gamesound.PlaySFX(gamesound.shot,.5f);
            Audio.Shot(.6f);
        }

    }
}
