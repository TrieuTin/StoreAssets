using UnityEngine;
using UnityEngine.AI;
using UnityEngine.UI;

public class CanonAgent : MonoBehaviour,IDamageable
{
    bool isFired = false;

    public float Speed=1f;
    public Transform Destination;
    NavMeshAgent _agent;                        
    Quaternion StartgunRotation;

    [SerializeField] Slider Health_Prefab;
    private Slider _health;
    
    [SerializeField] Transform firePosition;
    [SerializeField] GameObject bullet_prefab;

    [SerializeField] const int max_Blood=100;
    private int currentBlood = 0;
    private GameObject _enemy;
    public bool isAttacked = false;
    public GameObject Enemy { get => _enemy; set => _enemy = value; }

    void Start()
    {
        //Audio = GetComponent<AudioSource>();
       
        _health = Instantiate(Health_Prefab, this.transform.position, Quaternion.identity);
        _health.transform.SetParent(GameObject.Find("Canvas").transform);

        if (_health)
        {
            currentBlood = max_Blood;
            _health.maxValue = max_Blood;
            _health.value = currentBlood;

        }

        if (Destination != null)
        {
           
            _agent = GetComponent<NavMeshAgent>();
            _agent.SetDestination(Destination.position);
            _agent.speed = Speed;
            
            //StartgunRotation = gun.transform.rotation;
        }

    }

  
    private void Completed_duty()
    {
        _agent.ResetPath();
        Destroy(this.gameObject);
        Destroy(this._health.gameObject);
        _agent = null;
    }
    void Update()
    {
        if (_agent)
        {

            if (_agent.remainingDistance <= .1f)
            {
                Completed_duty();
            }
            if (_health) //show bloodbar on head
            {
                Renderer rend = GetComponentInChildren<Renderer>();

                float height = rend.bounds.size.y;

                Vector3 top = rend.bounds.center + Vector3.up * (height / 2);

                Vector3 screenPos = Camera.main.WorldToScreenPoint(top + Vector3.up * .5f);

                _health.GetComponent<RectTransform>().position = screenPos;
            }

        }

        Attack();
        if (_health.value <= 0) Die();
    }

    public void TakeDamage(int amount)
    {
        if(_health.value > 0)
        {
            if (amount > 0) currentBlood -= amount;

            _health.value = currentBlood;

           
        }
       
    }

    public void Die()
    {
        if(_agent)
            _agent.ResetPath();

        Effect.DisplayExplosion(this.transform.position, 2.5f, 2f);

        Destroy(this.gameObject, 0.1f);
        Destroy(this._health.gameObject, 0.1f);
        _agent = null;
    }

    public void Attack()
    {
        if (Enemy && !isAttacked)
        {
            _agent.isStopped = true;

            this.transform.rotation = LookGameObject.Rorate_CoordinateAxis_Y(Enemy, this.gameObject, 1.2f);
            var angleshot = Vector3.Angle(this.transform.position, Enemy.transform.position);
            if (angleshot <= 10)
            {
                GameObject bullet = Instantiate(bullet_prefab, firePosition.position, firePosition.rotation);

                var cb = bullet.GetComponent<CanonBall>();

                if (cb != null)
                {
                    cb.speed = 5f;
                    cb.damage = 10;
                    cb.parentTag = gameObject.tag;
                    cb.Launch(firePosition.forward); // direction
                                                     // gamesound.PlaySFX(gamesound.shot,.5f);
                    Audio.Shot(.6f);
                    isAttacked = true;
                }
            }
        }
        else { if (_agent) _agent.isStopped = false; }
    }
}
