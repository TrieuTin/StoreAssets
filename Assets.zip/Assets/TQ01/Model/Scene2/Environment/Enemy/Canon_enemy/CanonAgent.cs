using UnityEngine;
using UnityEngine.AI;
using UnityEngine.UI;

public class CanonAgent : MonoBehaviour,IDamageable
{
    bool isFired = false;

    public float Speed=1f;
    public Transform Destination;
    NavMeshAgent _agent;                        
    Quaternion StartgunRotation;

    [SerializeField] Slider Health_Prefab;
    private Slider _health;
    
    [SerializeField] Transform firePosition;
    [SerializeField] GameObject bullet_prefab;

    [SerializeField] const int max_Blood=100;
    private int currentBlood = 0;
    private GameObject _enemy;
    private float cooldownTimer = 0f;


    [SerializeField] GameObject body;

    
    public GameObject Enemy { get => _enemy; set => _enemy = value; }

    void Start()
    {
        //Audio = GetComponent<AudioSource>();
       
        _health = Instantiate(Health_Prefab, this.transform.position, Quaternion.identity);
        _health.transform.SetParent(GameObject.Find("Canvas").transform);

        if (_health)
        {
            currentBlood = max_Blood;
            _health.maxValue = max_Blood;
            _health.value = currentBlood;

        }

        if (Destination != null)
        {
           
            _agent = GetComponent<NavMeshAgent>();
            _agent.SetDestination(Destination.position);
            _agent.speed = Speed;
            
            //StartgunRotation = gun.transform.rotation;
        }

    }

  
    private void Completed_duty()
    {
        _agent.ResetPath();
        Destroy(this.gameObject);
        Destroy(this._health.gameObject);
        _agent = null;
    }
    void Update()
    {
        if (_agent)
        {

            if (_agent.remainingDistance <= .1f)
            {
                Completed_duty();
            }
            if (_health) //show bloodbar on head
            {
                Renderer rend = GetComponentInChildren<Renderer>();

                float height = rend.bounds.size.y;

                Vector3 top = rend.bounds.center + Vector3.up * (height / 2);

                Vector3 screenPos = Camera.main.WorldToScreenPoint(top + Vector3.up * .5f);

                _health.GetComponent<RectTransform>().position = screenPos;
            }

        }

        Attack();
        if (_health.value <= 0) Die();
    }

    public void TakeDamage(int amount)
    {
        if(_health.value > 0)
        {
            if (amount > 0) currentBlood -= amount;

            _health.value = currentBlood;

           
        }
       
    }

    public void Die()
    {
        if(_agent)
            _agent.ResetPath();

        Effect.DisplayExplosion(this.transform.position, 2.5f, 0.4f);

        Destroy(this.gameObject, 0.1f);
        Destroy(this._health.gameObject, 0.1f);
        _agent = null;
    }

    public void Attack()
    {
        cooldownTimer -= Time.deltaTime;
        if (cooldownTimer <= 0)
        {
            Fire();
            cooldownTimer = 2;
        }


    }
    void Fire()
    {
        GameObject bullet = Instantiate(bullet_prefab, firePosition.position, firePosition.rotation);

        var cb = bullet.GetComponent<CanonBall>();

        if (cb != null)
        {           
          
            switch (currentBlood)
            {
                case int n when n >= 70:
                    {

                        cb.speed = 15f;
                        cb.damage = 15;
                        break;
                    }
                case int n when n >= 50:
                    {
                        cb.speed = 10f;
                        cb.damage = 10;
                        break;
                    }

                default:
                    cb.speed = 7f;
                    cb.damage = 5;
                    break;
            }




            cb.parentTag = gameObject.tag;
            cb.Launch(firePosition.forward); // direction
                                             // gamesound.PlaySFX(gamesound.shot,.5f);
            Audio.Shot(.6f);                        
        }
    }
}
