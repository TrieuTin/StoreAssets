using UnityEngine;
using UnityEngine.AI;
using UnityEngine.UI;

public class FindDestination : MonoBehaviour
{
    public Transform Destination;
    int currentHealth = 10;
    public Slider slider_prefab;
    Slider slider_instant;
    NavMeshAgent agent;
    AudioClip clip;
    [SerializeField] AudioSource sound;
    public EnemyField data;
    int damage;
    int rate;
    public GameObject gun;
    Quaternion StartgunRotation;
  
    GameObject currentCollider;
    [SerializeField] ParticleSystem buttlet;
   
    void Start()
    {
        buttlet.Stop();

        var am = GameObject.Find("AudioSystem");
        if (am)
        {
            clip = am.GetComponent<AudioPlay>().clip_Explosion;
            sound.clip = clip;

        }

        if (Destination != null)
        {
            currentHealth = data.Heath;
            damage = data.Damage;
            rate = data.Rate;
            agent = GetComponent<NavMeshAgent>();
            agent.SetDestination(Destination.position);
            agent.speed = data.Speed;

            slider_instant = Instantiate(slider_prefab, gameObject.transform.position, Quaternion.identity);
            slider_instant.transform.SetParent(GameObject.Find("Canvas").transform);

            slider_instant.maxValue = currentHealth;
            slider_instant.value = currentHealth;

            sound.clip = clip;


            StartgunRotation = gun.transform.rotation;
        }
    }
    public void Hit(int damage)
    {
        slider_instant.value -= damage;
        if (slider_instant.value <= 0)
        {
            Death();
        }
    }

    void Death()
    {
        agent.speed = 0;
        DragGun.DisplayExplosion(this.transform.position);
        agent.ResetPath();
        Destroy(slider_instant.gameObject);
        Destroy(this.gameObject);
      
       
    }
    public void GetTurret(GameObject other)
    {
        if (currentCollider == null)
        {
            currentCollider = other;
        }
    }
    public void CLearTurret()
    {
        currentCollider = null;
    }
    void Shoot()
    {
        if (currentCollider)
        {
            int rnd = UnityEngine.Random.Range(1, 100);

            if (rnd < rate)
                currentCollider.GetComponent<GunControl>().Hit(damage);
        }
    }
    private void Update()
    {
        if (Destination != null)
        {

            if (agent.remainingDistance <= .1f)
            {
                agent.ResetPath();
                Destroy(this.gameObject);
                if (slider_instant)
                    Destroy(slider_instant.gameObject);
              
            }
            if (slider_instant)
            {
                slider_instant.transform.position = Camera.main.WorldToScreenPoint(gameObject.transform.position + Vector3.up * 0.4f);
            }

            if (currentCollider)
            {

                var AimAt = new Vector3(currentCollider.transform.position.x, gun.transform.position.y, currentCollider.transform.position.z);
                gun.transform.rotation = Quaternion.Slerp(gun.transform.rotation, Quaternion.LookRotation(AimAt - gun.transform.position), Time.deltaTime * 1.5f);


                /*Nham ban khi con nho hon hoac bang 15 do*/
                Vector3 directionToTarget = currentCollider.transform.position - gun.transform.position;

                buttlet.Play();
                if (Vector3.Angle(directionToTarget, gun.transform.forward) <= 30)
                {
                   
                    Shoot();
                }
            }

            else
            {
                gun.transform.localRotation = Quaternion.Lerp(gun.transform.localRotation, StartgunRotation, Time.deltaTime);
                buttlet.Stop();
            }
        }

    }
}
