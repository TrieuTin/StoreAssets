using UnityEngine;

public class AudioPlay : MonoBehaviour
{
    
    public AudioClip clip_Explosion;
    public AudioClip clip_Shoot1;
    public AudioClip clip_Shoot2;


    

  
   
}
