using UnityEngine;

public class TestCollider : MonoBehaviour
{
    void OnTriggerEnter(Collider other)
    {
        Debug.Log("TETEETETETETET");
    }

}
