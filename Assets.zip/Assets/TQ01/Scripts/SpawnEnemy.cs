using UnityEngine;

public class SpawnEnemy : MonoBehaviour
{
    public GameObject Prefab;
    public Transform Target;

    public float Start_Time = 2f;
    public float Rate_Time = 1.3f;
    void Start()
    {
        InvokeRepeating("Spawn", Start_Time, Rate_Time);
    }

    private void Spawn()
    {
        var instant = Instantiate(Prefab, this.transform.position, Quaternion.identity);

        instant.GetComponent<FindDestination>().Destination = Target;

        // instant.GetComponent<FindDestination>().tag ="Home";
    }

    // Update is called once per frame
    void Update()
    {

    }
}
