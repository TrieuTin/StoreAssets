using System;
using UnityEngine;
using UnityEngine.Pool;
public class ReturnToPool : MonoBehaviour
{
    ParticleSystem ps;

    [HideInInspector] public IObjectPool<ParticleSystem> pool;
    void Awake()
    {
        ps = GetComponent<ParticleSystem>();
        var main = ps.main;
        main.stopAction = ParticleSystemStopAction.Callback;
    }

    //void Start()
    //{      
    //    var main = ps.main;
    //    main.stopAction = ParticleSystemStopAction.Callback;
    //}
    void OnEnable()
    {
        Audio.Explotion();
    }
    void OnParticleSystemStopped()
    {
        if (pool != null)
            pool.Release(ps);
    }

}
